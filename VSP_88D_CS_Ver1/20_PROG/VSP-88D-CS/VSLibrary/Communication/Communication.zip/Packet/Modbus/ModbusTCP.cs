﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VSLibrary.Communication.Packet.Modbus
{
    internal class ModbusTCP
    {
    }
}
