﻿using System;
using System.Linq;
using System.Text;
using VSLibrary.Communication.Packet.Protocol;

namespace VSLibrary.Communication.Packet.Modbus
{
    /// <summary>
    /// Modbus ASCII 프로토콜 구현
    /// </summary>
    internal class ModbusAsciiProtocol : PacketProtocolBase
    {
        private const byte StartChar = (byte)':';
        private static readonly byte[] EndChars = new byte[] { 0x0D, 0x0A }; // \r\n

        public override byte[] BuildRequest(int unitId, byte functionCode, byte[] payload)
        {
            // 1) 바이너리 프레임: [Unit][Func][Data...]
            var pdu = new byte[2 + payload.Length];
            pdu[0] = (byte)unitId;
            pdu[1] = functionCode;
            Array.Copy(payload, 0, pdu, 2, payload.Length);

            // 2) LRC 계산 (PDU 전체)
            byte lrc = ComputeLrc(pdu, 0, pdu.Length);

            // 3) ASCII 헥스 변환: 각 바이트 → 2글자 헥스
            var hexChars = BitConverter.ToString(pdu.Append(lrc).ToArray())
                                     .Replace("-", string.Empty);

            // 4) 전체 프레임: ':' + hexChars + "\r\n"
            var frameAscii = StartChar
                          + hexChars
                          + Encoding.ASCII.GetString(EndChars);

            return Encoding.ASCII.GetBytes(frameAscii);
        }

        public override byte[] ParseResponse(byte[] frame)
        {
            // 1) 최소 길이 검사: Start + 최소 헥스(Unit+Func+LRC)*2 + CRLF
            if (frame.Length < 1 + (2 + 2 + 2) + 2)
                throw new FormatException("Frame too short");

            // 2) 시작·종료 문자 제거
            if (frame[0] != StartChar)
                throw new FormatException("Missing start ':'");
            if (frame[^2] != EndChars[0] || frame[^1] != EndChars[1])
                throw new FormatException("Missing CRLF terminator");

            var hexPart = Encoding.ASCII.GetString(frame, 1, frame.Length - 3);
            // 3) ASCII 헥스 → 바이트
            if (hexPart.Length % 2 != 0)
                throw new FormatException("Invalid hex length");

            int byteCount = hexPart.Length / 2;
            var raw = new byte[byteCount];
            for (int i = 0; i < byteCount; i++)
                raw[i] = Convert.ToByte(hexPart.Substring(i * 2, 2), 16);

            // 4) LRC 검증
            byte lrcRead = raw[^1];
            byte lrcCalc = ComputeLrc(raw, 0, raw.Length - 1);
            if (lrcRead != lrcCalc)
                throw new FormatException("LRC mismatch");

            // 5) PDU: [Unit][Func][Data...], 페이로드만 리턴
            var dataLength = raw.Length - 3; // 빼기(Unit, Func, LRC)
            var data = new byte[dataLength];
            Array.Copy(raw, 2, data, 0, dataLength);
            return data;
        }
    }
}
