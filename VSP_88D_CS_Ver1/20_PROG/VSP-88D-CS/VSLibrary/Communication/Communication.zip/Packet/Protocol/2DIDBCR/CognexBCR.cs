﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VSLibrary.Communication.Packet.Protocol._2DIDBCR
{
    internal class CognexBCR
    {
    }
}
