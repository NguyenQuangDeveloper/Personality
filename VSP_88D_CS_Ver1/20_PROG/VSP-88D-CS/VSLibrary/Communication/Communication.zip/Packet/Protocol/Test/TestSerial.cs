﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VSLibrary.Communication.Serial;

namespace VSLibrary.Communication.Packet.Protocol.Test
{
    /// <summary>
    /// SerialBase를 상속받아 실제 시리얼 통신을 수행하는 구체 클래스입니다.
    /// 프로토콜 파싱 없이, 원시 바이트 송수신만 필요할 때 사용합니다.
    /// </summary>
    public class TestSerial : SerialBase
    {
        /// <summary>
        /// 포트 설정을 받아 SerialBase 생성자 호출
        /// </summary>
        /// <param name="portName">COM 포트 이름 (예: "COM3")</param>
        /// <param name="baudRate">통신 속도 (예: 9600)</param>
        /// <param name="parity">패리티 비트 설정 (기본: None)</param>
        /// <param name="dataBits">데이터 비트 수 (기본: 8)</param>
        /// <param name="stopBits">스톱 비트 설정 (기본: One)</param>
        public TestSerial(ICommunicationConfig config)
            : base(config)
        {
        }

        /// <summary>
        /// ReceiveAsync가 필요한 경우, CommunicationBase에 정의된 DataReceived 이벤트를
        /// Task 기반으로 감쌀 수도 있습니다.
        /// </summary>
        public Task<byte[]> ReceiveAsync(CancellationToken cancellationToken = default)
        {
            var tcs = new TaskCompletionSource<byte[]>();
            void Handler(object s, byte[] data)
            {
                DataReceived -= Handler;
                tcs.TrySetResult(data);
            }
            DataReceived += Handler;
            if (cancellationToken != default)
                cancellationToken.Register(() => {
                    DataReceived -= Handler;
                    tcs.TrySetCanceled();
                });
            return tcs.Task;
        }
    }
}
