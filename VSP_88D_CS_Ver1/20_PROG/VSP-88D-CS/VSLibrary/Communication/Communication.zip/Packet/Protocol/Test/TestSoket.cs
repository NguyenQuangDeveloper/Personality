﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VSLibrary.Communication.Soket;

namespace VSLibrary.Communication.Packet.Protocol.Test
{
    public class TestSoket : SocketBase
    {
        public TestSoket(ICommunicationConfig config) :base(config)
        {
        }
    }
}
