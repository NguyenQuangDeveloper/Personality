﻿using CommunityToolkit.Mvvm.ComponentModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VSLibrary.Communication
{
    /// <summary>
    /// 공통 로직(이벤트 발생, 상태 관리 등)을 구현한 기본 클래스입니다.
    /// </summary>
    [ObservableObject]
    public abstract partial class CommunicationBase : ICommunication
    {
        public event EventHandler<byte[]> DataReceived;
        [ObservableProperty]
        public bool isOpen; 
        public ICommunicationConfig Config { get; set; }

        public abstract Task OpenAsync(CancellationToken cancellationToken = default);
        public abstract Task CloseAsync(CancellationToken cancellationToken = default);
        public abstract Task SendAsync(byte[] data, CancellationToken cancellationToken = default);
        protected void OnDataReceived(byte[] data) =>
            DataReceived?.Invoke(this, data);

        public virtual void Dispose()
        {
            try
            {
                // 동기 종결을 위해 Wait 사용
                CloseAsync().Wait();
            }
            catch
            {
                // 무시 or 로그
            }
        }
    }

    /// <summary>
    /// 공통 CRC/LRC/이스케이프 기능을 제공하는 추상 클래스
    /// </summary>
    public abstract class PacketProtocolBase : IPacketProtocol
    {
        // 하위에서 반드시 구현
        public abstract byte[] BuildRequest(int unitId, byte functionCode, byte[] payload);
        public abstract byte[] ParseResponse(byte[] frame);

        // CRC-16 계산 (Modbus RTU 등)
        protected ushort ComputeCrc16(byte[] data, int offset, int length)
        {
            ushort crc = 0xFFFF;
            for (int i = offset; i < offset + length; i++)
            {
                crc ^= data[i];
                for (int j = 0; j < 8; j++)
                    crc = (ushort)((crc & 1) != 0 ? (crc >> 1) ^ 0xA001 : crc >> 1);
            }
            return crc;
        }

        // LRC 계산 (Modbus ASCII 등)
        protected byte ComputeLrc(byte[] data, int offset, int length)
        {
            byte sum = 0;
            for (int i = offset; i < offset + length; i++)
                unchecked { sum += data[i]; }
            return (byte)((sum ^ 0xFF) + 1);
        }

        // 필요하다면 이스케이프, 프레임 구분자 헬퍼 등 추가
    }
}
