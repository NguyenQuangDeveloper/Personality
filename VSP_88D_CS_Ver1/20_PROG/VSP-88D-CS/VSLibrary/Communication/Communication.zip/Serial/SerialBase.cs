﻿using System;
using System.IO.Ports;
using System.Threading;
using System.Threading.Tasks;
using VSLibrary.Communication;

namespace VSLibrary.Communication.Serial
{
    /// <summary>
    /// 시리얼 통신 전용 추상 클래스 (SerialPort 래핑)
    /// </summary>
    public abstract class SerialBase : CommunicationBase
    {
        protected readonly SerialPort _serialPort;

        protected SerialBase(ICommunicationConfig config)
        {
            Config = config ?? throw new ArgumentNullException(nameof(config));

            _serialPort = new SerialPort(
                config.PortName,
                config.BaudRate,
                config.Parity,
                config.DataBits,
                config.StopBits
            );

            _serialPort.DataReceived += SerialPort_DataReceived;
        }

        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                var count = _serialPort.BytesToRead;
                var buffer = new byte[count];
                _serialPort.Read(buffer, 0, count);
                OnDataReceived(buffer);
            }
            catch (Exception ex)
            {
                // 예외 로깅 (필요시)
                Console.WriteLine($"Error reading from {_serialPort.PortName}", ex);
            }
        }

        public override Task OpenAsync(CancellationToken cancellationToken = default)
        {
            return Task.Run(() =>
            {
                try
                {
                    if (!_serialPort.IsOpen)
                    {
                        _serialPort.Open();
                        IsOpen = true;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[SerialBase] OpenAsync failed on {Config.PortName}: {ex.Message}");
                }
            }, cancellationToken);
        }

        public override Task CloseAsync(CancellationToken cancellationToken = default)
        {
            return Task.Run(() =>
            {
                try
                {
                    if (_serialPort.IsOpen)
                    {
                        _serialPort.Close();
                        IsOpen = false;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[SerialBase] CloseAsync failed on {Config.PortName}: {ex.Message}");
                }
            }, cancellationToken);
        }

        public override Task SendAsync(byte[] data, CancellationToken cancellationToken = default)
        {
            if (!_serialPort.IsOpen)
                Console.WriteLine("Serial port is not open.");

            try
            {
                _serialPort.Write(data, 0, data.Length);
            }
            catch (Exception ex)
            {
                // 예외 로깅
                Console.WriteLine($"Failed to send data on {Config.PortName}: {ex}");
                // 반드시 throw 해서 이 경로는 반환이 아니라 예외로 종료됨을 보장
                throw;
            }

            // 정상적으로 쓰기까지 완료된 경로는 여기서 Task를 반환
            return Task.CompletedTask;
        }
    }
}
