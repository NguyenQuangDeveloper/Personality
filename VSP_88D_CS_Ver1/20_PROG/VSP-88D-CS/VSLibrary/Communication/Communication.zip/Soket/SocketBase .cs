﻿using System;
using System.Linq;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using VSLibrary.Communication;

namespace VSLibrary.Communication.Soket
{
    /// <summary>
    /// TCP 소켓 통신 기본 구현
    /// </summary>
    public abstract class SocketBase : CommunicationBase
    {
        private readonly string _host;
        private readonly int _port;
        private TcpClient _client;
        private NetworkStream _stream;
        private CancellationTokenSource _cts;

        protected SocketBase(ICommunicationConfig config)
        {
            Config = config ?? throw new ArgumentNullException(nameof(config));
            _host = config.Host;
            _port = config.Port;
        }

        /// <summary>
        /// 비동기 연결 (TCP Connect)
        /// </summary>
        public override async Task OpenAsync(CancellationToken cancellationToken = default)
        {
            try
            {
                _client = new TcpClient();
                using (cancellationToken.Register(() => _client.Close()))
                {
                    await _client.ConnectAsync(_host, _port);
                }

                _stream = _client.GetStream();
                IsOpen = true;

                _cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
                _ = Task.Run(() => ReceiveLoopAsync(_cts.Token));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[SocketBase] OpenAsync 실패 ({_host}:{_port}): {ex.Message}");
            }
        }

        /// <summary>
        /// 비동기 해제
        /// </summary>
        public override Task CloseAsync(CancellationToken cancellationToken = default)
        {
            try
            {
                _cts?.Cancel();
                _stream?.Close();
                _client?.Close();
                IsOpen = false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[SocketBase] CloseAsync 실패 ({_host}:{_port}): {ex.Message}");
            }
            return Task.CompletedTask;
        }

        /// <summary>
        /// 비동기 전송
        /// </summary>
        public override Task SendAsync(byte[] data, CancellationToken cancellationToken = default)
        {
            if (!IsOpen)
            {
                Console.WriteLine($"[SocketBase] SendAsync 호출했으나 소켓이 열려 있지 않음 ({_host}:{_port})");
                return Task.CompletedTask;
            }

            try
            {
                _stream.WriteAsync(data, 0, data.Length, cancellationToken)
                       .ContinueWith(t =>
                       {
                           if (t.Exception != null)
                               Console.WriteLine($"[SocketBase] SendAsync 실패 ({_host}:{_port}): {t.Exception.InnerException?.Message}");
                       }, TaskContinuationOptions.OnlyOnFaulted);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[SocketBase] SendAsync 실패 ({_host}:{_port}): {ex.Message}");
            }

            return Task.CompletedTask;
        }

        /// <summary>
        /// 백그라운드 수신 루프
        /// </summary>
        private async Task ReceiveLoopAsync(CancellationToken token)
        {
            var buffer = new byte[1024];

            while (!token.IsCancellationRequested)
            {
                try
                {
                    int bytesRead = await _stream.ReadAsync(buffer, 0, buffer.Length, token);
                    if (bytesRead > 0)
                    {
                        var received = buffer.Take(bytesRead).ToArray();
                        OnDataReceived(received);
                    }
                }
                catch (OperationCanceledException)
                {
                    // 정상적인 취소 시 루프 종료
                    break;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[SocketBase] ReceiveLoop 에러 ({_host}:{_port}): {ex.Message}");
                    await Task.Delay(200, CancellationToken.None);
                }
            }
        }
    }
}
