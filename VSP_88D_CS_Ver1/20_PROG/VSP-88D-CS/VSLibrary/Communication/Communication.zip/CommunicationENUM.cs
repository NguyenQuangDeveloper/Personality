﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VSLibrary.Communication
{
    /// <summary>
    /// 통신 대상 식별자 열거형
    /// </summary>
    public enum CommunicationTarget
    {
        TestSerial,
        TestSoket,
        test
    }


    /// <summary>
    /// 지원하는 패킷(프레임) 형식 목록
    /// </summary>
    public enum PacketFormat
    {
        // ASCII 기반
        AsciiLine,      // "\r\n" 구분자 텍스트
        Csv,            // 쉼표 구분 필드
        Json,           // JSON 텍스트

        // Binary 기반
        FixedLength,    // 고정 길이
        LengthPrefixed, // 앞에 길이(2~4바이트)
        Tlv,            // Type-Length-Value 구조
        Hdlc,           // 플래그+이스케이프
        Checksum,       // 페이로드+CRC/LRC

        // Modbus 전용
        ModbusRtu,      // RTU 바이너리 + CRC16
        ModbusAscii,    // ASCII 헥스 + LRC
        ModbusTcp,      // TCP 위 MBAP 헤더
    }

    /// <summary>
    /// 모두가 구현해야 할 인터페이스
    /// </summary>
    public interface IPacketProtocol
    {
        byte[] BuildRequest(int unitId, byte functionCode, byte[] payload);
        byte[] ParseResponse(byte[] frame);
    }
}
