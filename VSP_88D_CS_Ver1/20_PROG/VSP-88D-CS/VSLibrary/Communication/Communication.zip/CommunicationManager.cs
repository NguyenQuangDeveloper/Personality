﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VSLibrary.Communication.Packet.Protocol.Test;
using VSLibrary.Communication.Serial;
using VSLibrary.Communication.Soket;
using VSLibrary.Controller;

namespace VSLibrary.Communication
{
    public class CommunicationManager
    {
        public Dictionary<string, ICommunication> Communication = new Dictionary<string, ICommunication>(StringComparer.OrdinalIgnoreCase);

        /// <summary>
        /// key: 사용자 식별 키, target: 통신 대상 열거형
        /// </summary>
        /// <param name="config">통신 키와 대상 매핑</param>
        public CommunicationManager(IDictionary<string, ICommunicationConfig> configMap)
        {
            if (configMap == null)
                throw new ArgumentNullException(nameof(configMap));

            foreach (var kv in configMap)
            {
                var key = kv.Key;
                var cfg = kv.Value;
                ICommunication comm;

                switch (cfg.Target)
                {
                    case CommunicationTarget.TestSerial:
                        comm = new TestSerial(cfg);
                        break;

                    case CommunicationTarget.TestSoket:
                        comm = new TestSoket(cfg);
                        break;

                    default:
                        // 지원하지 않는 Target은 건너뛴다
                        continue;
                }

                // 설정 주입
                comm.Config = cfg;
                // 필요시 자동 오픈: comm.OpenAsync().Wait();

                Communication[key] = comm;
            }
        }

        /// <summary>
        /// 생성된 ICommunication 인스턴스를 key로 가져옵니다.
        /// </summary>
        /// <param name="key">생성 시 사용한 키</param>
        /// <returns>ICommunication 인스턴스</returns>
        public ICommunication Get(string key)
        {
            if (string.IsNullOrWhiteSpace(key))
                throw new ArgumentException("key는 null 또는 공백이 될 수 없습니다.", nameof(key));

            if (Communication.TryGetValue(key, out var comm))
                return comm;

            throw new KeyNotFoundException($"통신 키 '{key}'에 해당하는 인스턴스가 없습니다.");
        }

        /// <summary>
        /// 모든 채널을 비동기로 엽니다.
        /// </summary>
        public Task OpenAllAsync(CancellationToken cancellationToken = default)
        {
            var openTasks = new List<Task>();
            foreach (var comm in Communication.Values)
            {
                openTasks.Add(comm.OpenAsync(cancellationToken));
            }
            return Task.WhenAll(openTasks);
        }

        /// <summary>
        /// 모든 채널을 비동기로 닫습니다.
        /// </summary>
        public Task CloseAllAsync(CancellationToken cancellationToken = default)
        {
            var closeTasks = new List<Task>();
            foreach (var comm in Communication.Values)
            {
                closeTasks.Add(comm.CloseAsync(cancellationToken));
            }
            return Task.WhenAll(closeTasks);
        }
    }
}
