﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VSLibrary.Controller
{
    /// <summary>
    /// 아날로그 I/O 제어를 위한 인터페이스입니다.
    /// 이 인터페이스는 아날로그 I/O 장치의 데이터 읽기 및 쓰기를 위한 기본 기능을 정의합니다.
    /// </summary>
    public interface IAIOBase
    {
        /// <summary>
        /// 아날로그 I/O 제어와 관련된 리소스를 해제합니다.
        /// </summary>
        void AnalogIOCtrlDispose();

        Dictionary<string, IAnalogIOData> GetAnalogIODataDictionary();   

        /// <summary>
        /// 지정된 아날로그 I/O 데이터 객체에 해당하는 채널의 값을 읽어 반환합니다.
        /// </summary>
        /// <param name="AioData">읽어올 아날로그 I/O 데이터 객체</param>
        /// <returns>읽어온 아날로그 채널 값</returns>
        double ReadChannelValue(IAnalogIOData AioData);

        /// <summary>
        /// 지정된 아날로그 I/O 데이터 객체에 해당하는 채널에 값을 기록합니다.
        /// </summary>
        /// <param name="AioData">쓰기할 아날로그 I/O 데이터 객체</param>
        /// <param name="value">설정할 아날로그 값</param>
        /// <returns>쓰기 작업의 성공 여부 (true: 성공, false: 실패)</returns>
        bool WriteChannelValue(IAnalogIOData AioData, double value);

        void UpdateAllChannelValues();
    }

    public interface IIOSettinglist
    {
        // ───────────────────────────────────────────────
        // 셋팅 파라미터
        // ───────────────────────────────────────────────

        /// <summary>
        /// I/O 타입을 나타냅니다.
        /// 입력(InPut) 또는 출력(OUTPut)으로 구분됩니다.
        /// </summary>
        public IOType IOType { get; set; }

        /// <summary>
        /// 와이어이름울 나타냅니다.
        /// 아날로그 I/O 채널에 대한 식별자로 사용됩니다.
        /// </summary>
        string WireName { get; set; }

        /// <summary>
        /// Equipment Mapping Name를 나타냅니다.
        /// 엔지니어링 네임 (또는 내부 논리 이름)
        /// 소프트웨어나 장비 로직에서 논리적으로 구분하기 위한 이름
        /// 코드에서 이 이름으로 접근할 수 있음
        /// </summary>
        string EmName { get; set; }

        /// <summary>
        /// UI나 내부 코드에서 읽기 쉬운 표시용 이름을 나타냅니다.
        /// 사용자가 식별하기 위한 이름 정보입니다.
        /// </summary>
        string StrdataName { get; set; }
    }

    /// <summary>
    /// 모든 AnalogIO 컨트롤러(Ajin, Comizoa)의 공통 데이터 인터페이스입니다.
    /// 이 인터페이스는 아날로그 I/O 장치의 설정 및 상태 정보를 제공하는 속성들을 정의합니다.
    /// </summary>
    public interface IAnalogIOData : IIOSettinglist
    {
        public IAIOBase Controller { get; set; }

        /// <summary>
        /// 아날로그 I/O 컨트롤러의 제조사를 나타냅니다.
        /// 예를 들어, Ajin 또는 Adlink 등을 지정합니다.
        /// </summary>
        public ControllerType ControllerType { get; set; }

        /// <summary>
        /// 모듈 번호를 나타냅니다.
        /// 보통 축 번호 등 특정 모듈을 식별하는 데 사용됩니다.
        /// </summary>
        short ModuleNumber { get; set; }        

        /// <summary>
        /// 모듈의 이름을 나타냅니다.
        /// 예: SIO_DO32P와 같이 모듈의 타입을 표현합니다.
        /// </summary>
        string ModuleName { get; set; }

        /// <summary>
        /// 채널 번호를 나타냅니다.
        /// 입력 또는 출력의 오프셋 값으로, 특정 아날로그 채널을 지정합니다.
        /// </summary>
        int Channel { get; set; }

        /// <summary>
        /// 측정 범위를 나타냅니다.
        /// 예를 들어, 입력 전압 범위 등의 설정 값입니다.
        /// </summary>
        public int Range { get; set; }

        /// <summary>
        /// 아날로그 값(AValue)을 나타냅니다.
        /// 실제 측정된 값이나 설정할 값을 의미합니다.
        /// </summary>
        public double AValue { get; set; }

        //콘트롤 기능
        public double ReadValue(bool forceRead = false);
        
        public void WriteValue(double value);

    }

    /// <summary>
    /// 다축 모션 컨트롤러의 디지털 I/O 제어를 위한 명령어 인터페이스입니다.
    /// </summary>
    public interface IDIOBase
    {
        /// <summary>
        /// 디지털 I/O 제어에 사용된 리소스를 해제합니다.
        /// </summary>
        void DigitalIOCtrlDispose();

        Dictionary<string, IDigitalIOData> GetDigitalIODataDictionary();

        /// <summary>
        /// 특정 비트의 현재 값을 읽어옵니다.
        /// </summary>
        /// <param name="dioData">비트 데이터 정보를 포함하는 객체</param>
        /// <returns>읽어온 비트 값 (true 또는 false)</returns>
        bool ReadBit(IDigitalIOData dioData);

        /// <summary>
        /// 특정 비트에 값을 기록합니다.
        /// </summary>
        /// <param name="dioData">비트 데이터 정보를 포함하는 객체</param>
        /// <param name="value">설정할 비트 값 (true 또는 false)</param>
        /// <returns>작업의 성공 여부 (true: 성공, false: 실패)</returns>
        bool WriteBit(IDigitalIOData dioData, bool value);

        /// <summary>
        /// 지정된 모듈의 32비트 데이터를 읽어옵니다.
        /// </summary>
        /// <param name="dioDataDict">모듈 이름과 해당 비트 데이터 정보 객체의 딕셔너리</param>
        /// <param name="key">읽어올 모듈의 키 값</param>
        void ReadDword(Dictionary<string, IDigitalIOData> dioDataDict, string key);

        /// <summary>
        /// 지정된 모듈에 32비트 데이터를 기록합니다.
        /// </summary>
        /// <param name="dioDataDict">모듈 이름과 해당 비트 데이터 정보 객체의 딕셔너리</param>
        /// <param name="key">데이터를 기록할 모듈의 키 값</param>
        /// <param name="value">설정할 32비트 데이터 값</param>
        void WriteDword(Dictionary<string, IDigitalIOData> dioDataDict, string key, uint value);

        /// <summary>
        /// 모든 입력/출력 모듈의 상태를 일괄 읽어 딕셔너리 값을 갱신합니다.
        /// </summary>
        void UpdateAllIOStates();
    }

    /// <summary>
    /// 모든 DigitalIO 컨트롤러(Ajin, Comizoa)의 공통 데이터 인터페이스입니다.
    /// </summary>
    public interface IDigitalIOData : IIOSettinglist
    {
        public IDIOBase Controller { get; set; }
        /// <summary>
        /// 모션 I/O의 경우 사용되는 모션 컨트롤러 유형을 지정합니다.
        /// </summary>
        //ControllerMotionType MotionController { get; set; }

        /// <summary>
        /// 축 번호를 나타냅니다.
        /// </summary>
        short AxisNo { get; set; }

        /// <summary>
        /// I/O 컨트롤러 유형을 지정합니다. (예: IO 보드 또는 모션 I/O)
        /// </summary>
        ControllerType ControllerType { get; set; }        

        /// <summary>
        /// 모듈의 이름을 나타냅니다. (예: SIO_DO32P)
        /// </summary>
        string ModuleName { get; set; }

        /// <summary>
        /// 모듈의 ID를 나타냅니다. (특정 모듈을 식별하기 위한 값)
        /// </summary>
        int ModuleIndex { get; set; }

        /// <summary>
        /// 현재 I/O의 상태를 나타냅니다.
        /// </summary>
        bool Value { get; set; }

        /// <summary>
        /// 폴링 상태의 I/O를 나타냅니다.
        /// 하이나 로우 엣지 감지 후, 감지 시간이 지난 후의 상태를 의미합니다.
        /// </summary>
        bool PollingState { get; set; }

        /// <summary>
        /// 상태 반전을 적용할지 여부를 지정합니다.
        /// </summary>
        bool StateReversal { get; set; }

        /// <summary>
        /// 입력 또는 출력의 오프셋을 지정합니다.
        /// (특정 비트를 지정하는 값)
        /// </summary>
        int Offset { get; set; }

        /// <summary>
        /// 하이 엣지 또는 로우 엣지 감지 여부를 나타냅니다.
        /// </summary>
        bool Edge { get; set; }

        /// <summary>
        /// 감지 시간을 지정합니다.
        /// </summary>
        int DetectionTime { get; set; }

        //콘트롤 기능
        bool IsOn(bool forceRead = false);
        bool IsOff(bool forceRead = false);
        void On();
        void Off();
    }

    /// <summary>
    /// 다축 모션 컨트롤러 명령어 인터페이스입니다.
    /// 이 인터페이스는 모션 제어를 위한 기본 동작(이동, 정지, 홈 이동, 서보 제어, 리미트 상태 확인 등)을 정의합니다.
    /// </summary>
    public interface IMotionBase
    {
        /// <summary>
        /// 모션 컨트롤러와 관련된 리소스를 해제합니다.
        /// </summary>
        void MotionCtrlDispose();

        Dictionary<int, IAxisData> GetMotionDataDictionary();

        /// <summary>
        /// 특정 축을 상대 좌표 기준으로 이동합니다.
        /// 이동 시 속도와 가속도 값을 적용합니다.
        /// </summary>
        /// <param name="axis">이동할 축 번호</param>
        /// <param name="position">상대 이동 거리</param>
        /// <param name="velocity">이동 속도</param>
        /// <param name="acceleration">가속도</param>
        void MoveToPosition(int axis, double position, double velocity, double acceleration);

        /// <summary>
        /// 특정 축을 절대 좌표 기준으로 이동합니다.
        /// 이동 시 속도와 가속도 값을 적용합니다.
        /// </summary>
        /// <param name="axis">이동할 축 번호</param>
        /// <param name="position">절대 위치</param>
        /// <param name="velocity">이동 속도</param>
        /// <param name="acceleration">가속도</param>
        void MoveToPoint(int axis, double position, double velocity, double acceleration);

        /// <summary>
        /// 특정 축을 지정한 위치 배열에 따라 반복 이동시킵니다.
        /// 이동 시 속도와 가속도를 적용하며, 지정된 횟수만큼 반복 실행합니다.
        /// </summary>
        /// <param name="axis">이동할 축 번호</param>
        /// <param name="position">이동할 위치 배열</param>
        /// <param name="velocity">이동 속도</param>
        /// <param name="acceleration">가속도</param>
        /// <param name="repeatCount">반복 횟수</param>
        void Repeat(int axis, double[] position, double velocity, double acceleration, int repeatCount);

        /// <summary>
        /// 특정 축의 모션을 정지합니다.
        /// </summary>
        /// <param name="axis">정지할 축 번호</param>
        bool StopMotion(int axis);

        /// <summary>
        /// 특정 축의 알람을 클리어합니다.
        /// </summary>
        /// <param name="axis">알람 클리어를 수행할 축 번호</param>
        Task ClearAlarm(int axis);

        /// <summary>
        /// 특정 축에 대해 홈 이동(원점 검색)을 수행합니다.
        /// </summary>
        /// <param name="axis">홈 이동을 수행할 축 번호</param>
        Task HomeMove(int axis, Motion_HomeConfig initset);

        /// <summary>
        /// 특정 축의 현재 실제 위치를 반환합니다.
        /// </summary>
        /// <param name="axis">대상 축 번호</param>
        /// <returns>현재 위치 값</returns>
        double GetPosition(int axis);

        /// <summary>
        /// 특정 축의 현재 명령 위치(목표 위치)를 반환합니다.
        /// </summary>
        /// <param name="axis">대상 축 번호</param>
        /// <returns>명령 위치 값</returns>
        double GetCmdPosition(int axis);

        /// <summary>
        /// 특정 축의 현재 속도를 반환합니다.
        /// </summary>
        /// <param name="axis"></param>
        /// <returns></returns>
        double GetVelocity(int axis);

        /// <summary>
        /// 특정 축의 서보를 켜거나 끕니다.
        /// </summary>
        /// <param name="axis">서보 제어할 축 번호</param>
        /// <param name="enabled">true: 서보 On, false: 서보 Off</param>
        void SetServoOnOff(int axis, bool enabled);

        /// <summary>
        /// 특정 축의 서보 상태를 확인합니다.
        /// </summary>
        /// <param name="axis">대상 축 번호</param>
        /// <returns>서보가 활성화되어 있으면 true, 그렇지 않으면 false</returns>
        bool IsServo(int axis);

        /// <summary>
        /// 특정 축의 홈 상태(원점 도달 여부)를 확인합니다.
        /// </summary>
        /// <param name="axis">대상 축 번호</param>
        /// <returns>홈 상태이면 true, 아니면 false</returns>
        bool IsHomed(int axis);

        /// <summary>
        /// 특정 축의 알람 상태를 확인합니다.
        /// </summary>
        /// <param name="axis">대상 축 번호</param>
        /// <returns>알람 상태이면 true, 아니면 false</returns>
        bool IsAlarm(int axis);

        /// <summary>
        /// 특정 축이 목표 위치에 도달했는지 확인합니다.
        /// </summary>
        /// <param name="axis">대상 축 번호</param>
        /// <returns>목표 위치에 도달했으면 true, 아니면 false</returns>
        bool IsMoving(int axis);

        /// <summary>
        /// 특정 축의 양(+) 리미트 상태를 확인합니다.
        /// </summary>
        /// <param name="axis">대상 축 번호</param>
        /// <returns>양 리미트 상태이면 true, 아니면 false</returns>
        bool IsPositiveLimit(int axis);

        /// <summary>
        /// 특정 축의 음(-) 리미트 상태를 확인합니다.
        /// </summary>
        /// <param name="axis">대상 축 번호</param>
        /// <returns>음 리미트 상태이면 true, 아니면 false</returns>
        bool IsNegativeLimit(int axis);

        public bool SetParameter(IAxisData motionData);

        public bool GetParameter(IAxisData motionData);

        void UpdateAllIOStatus();

        void UpdateAllPosition();


        //IAxisData GetParameters(int axis);

        //bool SetParameters(int axis, IAxisData motionData);
    }

    public interface IAxisSettinglist
    {
        // ───────────────────────────────────────────────
        // 셋팅 파라미터
        // ───────────────────────────────────────────────

        //기본파라미터
        ControllerType ControllerType { get; set; }
        short AxisNo { get; set; }
        string AxisName { get; set; }
        string StrAxisData { get; set; }

        //이동거리 계산에 필요한 변수
        double LeadPitch { get; set; } // 가속도 볼스크류 피치 (mm/회전)
        double PulsesPerRev { get; set; } // 모터 1회전당 펄스 수 (pulse/rev)
        double GearRatio { get; set; } // 기어비 (입력 회전수 대비 출력 회전수)

        byte PulseOutputMode { get; set; } // 펄스 출력 방식*
        byte EncInputMode { get; set; } // 엔코더 입력 방식*

        //속도 제한
        double MinSpeed { get; set; }
        double MaxSpeed { get; set; }

        // 서보 모터 활성화 반전 여부
        bool ServoEnabledReversal { get; set; }

        //레벨 설정 셋팅
        public bool LvSet_EndLimitP { get; set; } // 양(+) 방향 엔드 리미트
        public bool LvSet_EndLimitN { get; set; } // 음(-) 방향 엔드 리미트
        public bool LvSet_SlowLimitP { get; set; } // 양(+) 방향 슬로우 리미트
        public bool LvSet_SlowLimitN { get; set; } // 음(-) 방향 슬로우 리미트
        public bool LvSet_InPosition { get; set; } // 위치결정 완료 신호
        public bool LvSet_Alarm { get; set; } // 축의 알람 상태
    }

    /// <summary>
    /// 모든 모션 컨트롤러(Ajin, Comizoa)의 공통 데이터 인터페이스입니다.
    /// 이 인터페이스는 모션 제어에 필요한 축 정보, 속도, 가속도, 위치, 엔코더 설정 및 레벨 신호 상태 등을 포함합니다.
    /// </summary>
    public interface IAxisData : IAxisSettinglist
    {
        // ───────────────────────────────────────────────
        // 기본 정보
        // ───────────────────────────────────────────────
        IMotionBase Controller { get; set; }        

        bool ServoEnabled { get; set; } //서보상태
        bool HomeState { get; set; } //홈상태
        bool Alarm { get; set; } //알람
        bool PositiveLimit { get; set; } //+리미트
        bool NegativeLimit { get; set; } //-리미트
        bool InPosition { get; set; } //인포지션

        // ───────────────────────────────────────────────
        // 명령 위치 및 속도, 가속도  현재 위치 및 속도
        // ───────────────────────────────────────────────

        //명령 위치,속도,가속도
        double CurrentPosition { get; set; }
        double CurrentVelocity { get; set; }
        double CurrentAcceleration { get; set; }

        //현재 위치,속도
        double Position { get; set; }
        double Velocity { get; set; }        

        // ───────────────────────────────────────────────
        // 제어 함수
        // ───────────────────────────────────────────────
        void MoveToPosition(double position, double velocity, double acceleration);
        void MoveToPoint(double position, double velocity, double acceleration);
        void Repeat(double[] position, double velocity, double acceleration, int repeatCount);

        bool StopMotion();
        bool SetServoOnOff(bool enabled);
        Task HomeMove(Motion_HomeConfig initset);

        // ───────────────────────────────────────────────
        // 상태 확인 및 IO
        // ───────────────────────────────────────────────
        double GetPosition();
        double GetCmdPosition();
        double GetVelocity();

        bool IsServo();
        bool IsHomed();
        bool IsAlarm();
        bool IsMoving();
        bool IsPositiveLimit();
        bool IsNegativeLimit();

        bool ClearAlarm();

        // ───────────────────────────────────────────────
        // 파라미터 저장/복원
        // ───────────────────────────────────────────────
        bool GetParameter();
        bool SetParameter(IAxisData motionData);
    }
}
