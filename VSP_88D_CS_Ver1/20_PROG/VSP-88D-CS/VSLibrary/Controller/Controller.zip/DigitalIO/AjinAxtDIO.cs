using System.Collections.ObjectModel;
using System.Runtime.InteropServices;
using VSLibrary.Common.MVVM.Interfaces;

namespace VSLibrary.Controller.DigitalIO
{
    /// <summary>
    /// AjinDIOCtrl - 보드 데이터 관리 및 읽기/쓰기 제어 클래스.
    /// 이 클래스는 AbstractDigitalIOController를 상속받아 Ajin 제조사의 디지털 I/O 초기화, 데이터 처리 및 모듈 제어 기능을 제공합니다.
    /// </summary>
    public class AjinAxtDIO : DIOBase
    {
        /// <summary>
        /// 디지털 I/O 데이터들을 모듈별로 저장하는 딕셔너리.
        /// 키는 와이어 이름, 값은 해당 I/O 데이터 객체입니다.
        /// </summary>
        private Dictionary<string, IDigitalIOData> _digitalIOData = new Dictionary<string, IDigitalIOData>();

        private Dictionary<string, int> _iocount;

        private bool _isInitialized = false;  // 카드 초기화 여부

        /// <summary>
        /// Ajin_DigitalIO DIO 컨트롤러 생성자.
        /// 제조사가 Ajin으로 설정된 상태에서 모듈 초기화를 수행합니다.
        /// </summary>
        /// <param name="container">DI 컨테이너 (필요한 경우 의존성 주입을 위해 사용)</param>
        public AjinAxtDIO(Dictionary<string, int> count)
        {
            _iocount = count;

            // 초기화 전 데이터 할당이 필요한 경우 _dBdata 초기화 가능 (현재 주석 처리됨)
            if (IsInitialized())
            {
                OpenDevice();
                _isInitialized = true;
            }

            // 테스트용 초기화 메서드 (디버깅용, 실제 운영에서는 주석 처리)
            test();            
        }

        /// <summary>
        /// 지정된 와이어 이름이 딕셔너리에 존재하는지와 초기화 상태를 확인합니다.
        /// </summary>
        /// <param name="IONo">확인할 와이어 이름</param>
        /// <returns>존재하지 않거나 초기화되지 않은 경우 false, 그렇지 않으면 true</returns>
        private bool CheckDic(string IONo)
        {
            if (!_digitalIOData.ContainsKey(IONo))
            {
                Console.WriteLine($"[오류] 디지털 IO {IONo}의 데이터가 존재하지 않습니다.");
                return false;
            }
            return true;
        }

        /// <summary>
        /// 테스트 및 디버깅용 초기화 메서드.
        /// 15개의 더미 디지털 I/O 데이터를 생성하여 딕셔너리에 추가합니다.
        /// </summary>
        private void test()
        {
            for (int i = 0; i < 15; i++)
            {
                DIOData strdata = new DIOData
                {
                    Controller = this,
                    ControllerType = ControllerType.DIO_AjinAXT,
                    IOType = IOType.OUTPut,
                    WireName = $"Y{i + _iocount["DOutput"]:X3}",    // 와이어번호 (예: Y000, Y001, ...)
                    StrdataName = "",         // IO 이름 (필요 시 설정)
                    ModuleName = "",          // 모듈의 이름 (예: SIO_DO32P)
                    ModuleIndex = i,              // 모듈의 ID (특정 모듈 식별)
                    Value = false,             // 초기 IO 상태
                    PollingState = false,     // 폴링 후 상태
                    StateReversal = false,
                    Offset = 0,               // 비트 오프셋
                    Edge = false,             // 엣지 감지 여부
                    DetectionTime = 0         // 감지 시간
                };

                _digitalIOData.Add(strdata.WireName, strdata);
            }
            _iocount["DOutput"] = _iocount["DOutput"] + 15;
        }

        /// <summary>
        /// 제조사 및 모듈별 초기화 작업을 수행합니다.
        /// CAxtDIO 초기화와 장치 열기를 포함합니다.
        /// </summary>
        /// <returns>초기화 성공 여부 (true: 초기화 성공, false: 실패)</returns>
        private bool IsInitialized()
        {
            if (CAxtDIO.InitializeDIO() == 0)
            {
                return false;
            }            

            return true;
        }

        /// <summary>
        /// 모듈들을 열고 각 모듈에 대한 입력/출력 데이터를 생성하여 딕셔너리에 추가합니다.
        /// </summary>
        public void OpenDevice()
        {
            int moduleCount = CAxtDIO.DIOget_module_count();
            int inputCount = 0, outputCount = 0;

            for (int i = 0; i < moduleCount; i++)
            {
                int moduleID = CAxtDIO.DIOget_module_id((short)i);
                AXT_FUNC_MODULE moduleType = (AXT_FUNC_MODULE)moduleID;

                // 출력 모듈 처리
                if (moduleType == AXT_FUNC_MODULE.AXT_SIO_DO32P || moduleType == AXT_FUNC_MODULE.AXT_SIO_DO32T)
                {
                    AddOutputModule(moduleType, i, ref outputCount);
                }
                // DI/DO 모듈 처리
                else if (moduleType == AXT_FUNC_MODULE.AXT_SIO_DB32P || moduleType == AXT_FUNC_MODULE.AXT_SIO_DB32T)
                {
                    AddInputModule(moduleType, i, ref inputCount);
                    AddOutputModule(moduleType, i, ref outputCount);
                }
                // 입력 전용 모듈 처리
                else if (moduleType == AXT_FUNC_MODULE.AXT_SIO_DI32)
                {
                    AddInputModule(moduleType, i, ref inputCount);
                }
            }
        }

        /// <summary>
        /// 입력 모듈 데이터를 처리하여 딕셔너리에 추가합니다.
        /// </summary>
        /// <param name="moduleType">모듈 유형</param>
        /// <param name="moduleIndex">모듈 인덱스</param>
        /// <param name="inputCount">현재 입력 모듈 개수 (ref 매개변수)</param>
        private void AddInputModule(AXT_FUNC_MODULE moduleType, int moduleIndex, ref int inputCount)
        {
            int inputNumber = CAxtDIO.DIOget_input_number((short)moduleIndex);
            string moduleName = moduleType == AXT_FUNC_MODULE.AXT_SIO_DB32P ? "SIO_DB32P" : "SIO_DB32T";

            for (int i = 0; i < inputNumber; i++)
            {
                DIOData strdata = new DIOData
                {
                    Controller = this,
                    ControllerType = ControllerType.DIO_AjinAXT,
                    IOType = IOType.InPut,
                    WireName = $"X{inputCount + _iocount["DInput"]:X3}", // 와이어번호 (예: X000, X001, ...)
                    StrdataName = "",
                    ModuleName = moduleType == AXT_FUNC_MODULE.AXT_SIO_DI32 ? "SIO_DI32" : moduleName,
                    ModuleIndex = moduleIndex,
                    Value = false,
                    PollingState = false,
                    StateReversal = false,
                    Offset = i,
                    Edge = false,
                    DetectionTime = 0
                };
                _digitalIOData.Add(strdata.WireName, strdata);
                inputCount++;
            }
            _iocount["DInput"] = _iocount["DInput"] + inputCount;
        }

        /// <summary>
        /// 출력 모듈 데이터를 처리하여 딕셔너리에 추가합니다.
        /// </summary>
        /// <param name="moduleType">모듈 유형</param>
        /// <param name="moduleIndex">모듈 인덱스</param>
        /// <param name="outputCount">현재 출력 모듈 개수 (ref 매개변수)</param>
        private void AddOutputModule(AXT_FUNC_MODULE moduleType, int moduleIndex, ref int outputCount)
        {
            int outputNumber = CAxtDIO.DIOget_output_number((short)moduleIndex);
            string moduleName = moduleType == AXT_FUNC_MODULE.AXT_SIO_DO32P ? "SIO_DO32P" : "SIO_DO32T";

            for (int i = 0; i < outputNumber; i++)
            {
                DIOData strdata = new DIOData
                {
                    Controller = this,
                    ControllerType = ControllerType.DIO_AjinAXT,
                    IOType = IOType.OUTPut,
                    WireName = $"Y{outputCount + _iocount["DOutput"]:X3}", // 와이어번호 (예: Y000, Y001, ...)
                    StrdataName = "",
                    ModuleName = moduleName,
                    ModuleIndex = moduleIndex,
                    Value = false,
                    PollingState = false,
                    StateReversal = false,
                    Offset = i,
                    Edge = false,
                    DetectionTime = 0
                };
                _digitalIOData.Add(strdata.WireName, strdata);
                outputCount++;
            }
            _iocount["DOutput"] = _iocount["DOutput"] + outputCount;
        }

        /// <summary>
        /// 디지털 I/O 데이터 딕셔너리를 반환합니다.
        /// </summary>
        /// <returns>키: 와이어 이름, 값: 해당 I/O 데이터 객체</returns>
        public override Dictionary<string, IDigitalIOData> GetDigitalIODataDictionary()
        {
            return _digitalIOData.ToDictionary(
                kvp => kvp.Key, kvp => kvp.Value
            );
        }

        /// <summary>
        /// 프로그램 종료 시 리소스를 해제하는 메서드.
        /// </summary>
        public override void DigitalIOCtrlDispose()
        {
            // 필요 시 연결 종료 및 리소스 해제 작업을 수행
        }

        /// <summary>
        /// 특정 비트 값을 읽어옵니다.
        /// </summary>
        /// <param name="dioData">읽을 비트 데이터 객체</param>
        /// <returns>읽은 비트 값 (true/false)</returns>
        /// <exception cref="InvalidOperationException">모듈이 초기화되지 않은 경우</exception>
        public override bool ReadBit(IDigitalIOData dioData)
        {
            if (dioData.IOType == IOType.InPut)
            {
                dioData.Value = CAxtDIO.DIOread_inport_bit((short)dioData.ModuleIndex, (ushort)dioData.Offset) == 1;
            }
            else
            {
                dioData.Value = CAxtDIO.DIOread_outport_bit((short)dioData.ModuleIndex, (ushort)dioData.Offset) == 1;
            }

            return dioData.Value;
        }

        /// <summary>
        /// 특정 비트에 지정된 값을 씁니다.
        /// </summary>
        /// <param name="dioData">쓰기할 비트 데이터 객체</param>
        /// <param name="value">설정할 비트 값 (true/false)</param>
        /// <returns>쓰기 후 읽은 비트 값</returns>
        /// <exception cref="InvalidOperationException">
        /// 모듈이 초기화되지 않았거나, I/O 타입이 입력일 경우 예외 발생
        /// </exception>
        public override bool WriteBit(IDigitalIOData dioData, bool value)
        {
            if (dioData.IOType == IOType.OUTPut)
            {
                CAxtDIO.DIOwrite_outport_bit((short)dioData.ModuleIndex, (ushort)dioData.Offset, value ? 1 : 0);
                return ReadBit(dioData);
            }
            else
            {
                throw new InvalidOperationException("해당 데이터는 인풋입니다.");
            }
        }

        /// <summary>
        /// 특정 모듈의 32비트 데이터를 읽어와 각 비트의 상태를 해당 I/O 데이터 객체에 업데이트합니다.
        /// </summary>
        /// <param name="dioDataDict">디지털 I/O 데이터를 포함하는 딕셔너리</param>
        /// <param name="key">읽어올 모듈의 키 값</param>
        /// <exception cref="InvalidOperationException">모듈이 초기화되지 않은 경우</exception>
        public override void ReadDword(Dictionary<string, IDigitalIOData> dioDataDict, string key)
        {
            var targetIO = dioDataDict[key];
            var isInput = targetIO.IOType == IOType.InPut;
            var ioIndex = targetIO.ModuleIndex;

            uint data = isInput
                ? CAxtDIO.DIOread_inport_dword((short)ioIndex, 0)
                : CAxtDIO.DIOread_outport_dword((short)ioIndex, 0);

            var sameModuleItems = dioDataDict.Values
                .Where(x => x.ModuleIndex == ioIndex && x.IOType == targetIO.IOType).ToList();

            foreach (var item in sameModuleItems)
            {
                item.Value = (data & 1u << item.Offset) != 0;
            }
        }

        /// <summary>
        /// 특정 모듈에 32비트 데이터를 기록한 후, 해당 모듈의 상태를 업데이트합니다.
        /// </summary>
        /// <param name="dioDataDict">디지털 I/O 데이터를 포함하는 딕셔너리</param>
        /// <param name="key">데이터를 기록할 모듈의 키 값</param>
        /// <param name="value">설정할 32비트 데이터 값</param>
        /// <exception cref="InvalidOperationException">모듈이 초기화되지 않은 경우</exception>
        public override void WriteDword(Dictionary<string, IDigitalIOData> dioDataDict, string key, uint value)
        {
            CAxtDIO.DIOwrite_outport_dword((short)dioDataDict[key].ModuleIndex, 0, value);

            // 데이터 기록 후, 상태를 업데이트하기 위해 다시 읽기 수행
            ReadDword(dioDataDict, key);
        }

        /// <summary>
        /// 모든 입력/출력 모듈의 상태를 일괄 읽어 딕셔너리 값을 갱신합니다.
        /// </summary>
        public override void UpdateAllIOStates()
        {
            if (!_isInitialized) return;

            // 입력 모듈 상태 갱신
            var inputModules = _digitalIOData.Values
                .Where(d => d.IOType == IOType.InPut)
                .GroupBy(d => d.ModuleIndex);

            foreach (var moduleGroup in inputModules)
            {
                var anyItem = moduleGroup.First();
                ReadDword(_digitalIOData, anyItem.WireName);
            }

            // 출력 모듈 상태 갱신
            var outputModules = _digitalIOData.Values
                .Where(d => d.IOType == IOType.OUTPut)
                .GroupBy(d => d.ModuleIndex);

            foreach (var moduleGroup in outputModules)
            {
                var anyItem = moduleGroup.First();
                ReadDword(_digitalIOData, anyItem.WireName);
            }
        }
    }
}
