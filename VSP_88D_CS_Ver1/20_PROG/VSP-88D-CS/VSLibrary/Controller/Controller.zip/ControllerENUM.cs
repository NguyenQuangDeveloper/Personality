﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VSLibrary.Controller
{
    /// <summary>
    /// I/O의 방향을 정의합니다.
    /// </summary>
    public enum IOType
    {
        /// <summary>
        /// 입력
        /// </summary>
        InPut,
        /// <summary>
        /// 출력
        /// </summary>
        OUTPut
    }

    /// <summary>
    /// 아날로그 I/O 컨트롤러 유형을 정의합니다.
    /// </summary>
    public enum ControllerType
    {
        AIO_AjinAXT,
        AIO_Adlink,
        DIO_AjinAXT,
        DIO_AjinAXTUniversalIO,
        DIO_Comizoa,
        Motion_AjinAXT,
        Motion_Comizoa
    }
}
