﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using VSLibrary.Common.MVVM.ViewModels;

namespace VSLibrary.Controller
{
    /// <summary>
    /// 아날로그 I/O 컨트롤러의 기본 추상 클래스입니다.
    /// 이 클래스는 IAnalogIOController 인터페이스를 구현하며, 아날로그 I/O 장치의 데이터 관리,
    /// 채널 읽기/쓰기 및 디바이스 목록 반환 기능을 위한 추상 메서드를 정의합니다.
    /// 파생 클래스에서 구체적인 동작을 구현해야 합니다.
    /// </summary>
    public abstract class AIOBase : IAIOBase
    {
        /// <summary>
        /// 아날로그 I/O 데이터 딕셔너리를 반환합니다.
        /// 키는 와이어 이름이며, 값은 해당 IAnalogIOData 객체입니다.
        /// </summary>
        public abstract Dictionary<string, IAnalogIOData> GetAnalogIODataDictionary();

        /// <summary>
        /// 아날로그 I/O 컨트롤러와 관련된 리소스를 해제합니다.
        /// 기본 구현은 빈 메서드이며, 필요 시 파생 클래스에서 재정의할 수 있습니다.
        /// </summary>
        public virtual void AnalogIOCtrlDispose() { }

        /// <summary>
        /// 아날로그 I/O 컨트롤러의 상태를 모니터링합니다.
        /// 기본 구현은 빈 메서드이며, 필요한 경우 파생 클래스에서 기능을 재정의하여 사용할 수 있습니다.
        /// </summary>
        public virtual void MonitorAnalogIOController() { }

        /// <summary>
        /// 지정된 아날로그 I/O 데이터 객체에 해당하는 채널의 값을 읽어 반환합니다.
        /// </summary>
        /// <param name="AioData">읽어올 아날로그 I/O 데이터 객체</param>
        /// <returns>읽어온 아날로그 채널 값</returns>
        public abstract double ReadChannelValue(IAnalogIOData AioData);

        /// <summary>
        /// 지정된 아날로그 I/O 데이터 객체에 해당하는 채널에 값을 기록합니다.
        /// </summary>
        /// <param name="AioData">쓰기할 아날로그 I/O 데이터 객체</param>
        /// <param name="value">설정할 아날로그 값</param>
        /// <returns>쓰기 작업의 성공 여부 (true: 성공, false: 실패)</returns>
        public abstract bool WriteChannelValue(IAnalogIOData AioData, double value);

        /// <summary>
        /// 모든 아날로그 입력 채널을 일괄 읽고 내부 데이터 딕셔너리에 값을 갱신합니다.
        /// </summary>
        public abstract void UpdateAllChannelValues();
    }

    public abstract class AIODataBase : ViewModelBase, IAnalogIOData
    {
        public abstract IAIOBase Controller { get; set; }
        public abstract ControllerType ControllerType { get; set; }
        public abstract IOType IOType { get; set; }
        public abstract short ModuleNumber { get; set; }
        public abstract string WireName { get; set; }
        public abstract string EmName { get; set; }
        public abstract string StrdataName { get; set; }
        public abstract string ModuleName { get; set; }
        public abstract int Channel { get; set; }
        public abstract int Range { get; set; }
        public abstract double AValue { get; set; }        

        public virtual double ReadValue(bool forceRead = false)
        {
            if (Controller == null)
                MessageBox.Show("컨트롤러가 연결되지 않았습니다.", "오류", MessageBoxButton.OK, MessageBoxImage.Error);

            if (forceRead)
            {
                // 컨트롤러에서 강제로 다시 읽기
                AValue = Controller.ReadChannelValue(this);
            }

            return AValue;
        }
        public virtual void WriteValue(double value)
        {
            if (IOType != IOType.OUTPut)
                MessageBox.Show("이 채널은 출력 전용입니다.", "오류", MessageBoxButton.OK, MessageBoxImage.Error);
            //throw new InvalidOperationException("이 채널은 출력 전용입니다.");

            if (Controller == null)
                MessageBox.Show("컨트롤러가 연결되지 않았습니다.", "오류", MessageBoxButton.OK, MessageBoxImage.Error);
            //throw new InvalidOperationException("컨트롤러가 연결되지 않았습니다.");

            Controller.WriteChannelValue(this, value);
            AValue = value;
        }
    }

    /// <summary>
    /// 디지털 I/O 컨트롤러의 기본 추상 클래스입니다.
    /// 이 클래스는 IDigitalIOController 인터페이스를 구현하며, 공통 기능의 기본 구조를 제공합니다.
    /// </summary>
    public abstract class DIOBase : IDIOBase
    {

        // ==================== 디지털 I/O 컨트롤러 기능 ====================

        /// <summary>
        /// 디지털 I/O 데이터를 포함하는 딕셔너리를 반환합니다.
        /// </summary>
        /// <returns>키: 모듈 이름, 값: 해당 디지털 I/O 데이터 객체</returns>
        public abstract Dictionary<string, IDigitalIOData> GetDigitalIODataDictionary();

        /// <summary>
        /// 디지털 I/O 컨트롤러 관련 리소스를 해제합니다.
        /// </summary>
        public virtual void DigitalIOCtrlDispose() { }

        /// <summary>
        /// 디지털 I/O 컨트롤러의 상태를 모니터링합니다.
        /// 기본 구현은 빈 메서드이며, 필요한 경우 파생 클래스에서 기능을 재정의하여 사용할 수 있습니다.
        /// </summary>
        public virtual void MonitorDigitalIOController() { }

        /// <summary>
        /// 특정 비트의 현재 값을 읽습니다.
        /// </summary>
        /// <param name="dioData">읽을 비트 정보를 담은 객체</param>
        /// <returns>비트의 현재 값 (true/false)</returns>
        public abstract bool ReadBit(IDigitalIOData dioData);

        /// <summary>
        /// 특정 비트에 값을 기록합니다.
        /// </summary>
        /// <param name="dioData">쓰기할 비트 정보를 담은 객체</param>
        /// <param name="value">설정할 값 (true/false)</param>
        /// <returns>작업의 성공 여부 (true: 성공, false: 실패)</returns>
        public abstract bool WriteBit(IDigitalIOData dioData, bool value);

        /// <summary>
        /// 특정 모듈의 32비트 데이터를 읽습니다.
        /// </summary>
        /// <param name="dioDataDict">모듈 이름과 디지털 I/O 데이터를 매핑한 딕셔너리</param>
        /// <param name="key">데이터를 읽을 모듈의 키</param>
        public abstract void ReadDword(Dictionary<string, IDigitalIOData> dioDataDict, string key);

        /// <summary>
        /// 특정 모듈의 32비트 데이터를 씁니다.
        /// </summary>
        /// <param name="dioDataDict">모듈 이름과 디지털 I/O 데이터를 매핑한 딕셔너리</param>
        /// <param name="key">데이터를 기록할 모듈의 키</param>
        /// <param name="value">쓰기할 32비트 값</param>
        public abstract void WriteDword(Dictionary<string, IDigitalIOData> dioDataDict, string key, uint value);

        /// <summary>
        /// 모든 입력/출력 모듈의 상태를 일괄 읽어 딕셔너리 값을 갱신합니다.
        /// </summary>
        public abstract void UpdateAllIOStates();
    }

    public abstract class DIODataBase : ViewModelBase, IDigitalIOData
    {
        public abstract IDIOBase Controller { get; set; }
        public abstract short AxisNo { get; set; }
        public abstract ControllerType ControllerType { get; set; }
        public abstract IOType IOType { get; set; }
        public abstract string WireName { get; set; }
        public abstract string EmName { get; set; }
        public abstract string StrdataName { get; set; }
        public abstract string ModuleName { get; set; }
        public abstract int ModuleIndex { get; set; }
        public abstract bool Value { get; set; }
        public abstract bool PollingState { get; set; }
        public abstract bool StateReversal { get; set; }
        public abstract int Offset { get; set; }
        public abstract bool Edge { get; set; }
        public abstract int DetectionTime { get; set; }

        //컨트롤
        public virtual bool IsOn(bool forceRead = false)
        {
            if (Controller == null)
                MessageBox.Show("DIO 컨트롤러가 연결되지 않았습니다.", "오류", MessageBoxButton.OK, MessageBoxImage.Error);
            //throw new InvalidOperationException("DIO 컨트롤러가 연결되지 않았습니다.");

            if (forceRead)
                Value = Controller.ReadBit(this);

            return Value;
        }

        public virtual bool IsOff(bool forceRead = false)
        {
            return !IsOn(forceRead);
        }

        public virtual void On()
        {
            if (IOType != IOType.OUTPut)
                MessageBox.Show("해당 채널은 출력 전용이 아닙니다.", "오류", MessageBoxButton.OK, MessageBoxImage.Error);

            if (Controller == null)
                MessageBox.Show("DIO 컨트롤러가 연결되지 않았습니다.", "오류", MessageBoxButton.OK, MessageBoxImage.Error);

            Controller.WriteBit(this, true);
        }

        public virtual void Off()
        {
            if (IOType != IOType.OUTPut)
                MessageBox.Show("해당 채널은 출력 전용이 아닙니다.", "오류", MessageBoxButton.OK, MessageBoxImage.Error);

            if (Controller == null)
                MessageBox.Show("DIO 컨트롤러가 연결되지 않았습니다.", "오류", MessageBoxButton.OK, MessageBoxImage.Error);
            //throw new InvalidOperationException("DIO 컨트롤러가 연결되지 않았습니다.");

            Controller.WriteBit(this, false);
        }
    }

    /// <summary>
    /// 다축 모션 컨트롤러의 기본 추상 클래스 (유니버셜 I/O 포함).
    /// 이 클래스는 <see cref="AbstractDigitalIOController"/>와 <see cref="IMotionController"/>를 상속받아,
    /// 모션 제어와 관련된 다양한 동작(이동, 정지, 홈 이동, 서보 제어, 파라미터 관리, I/O 제어 등)을 추상적으로 정의합니다.
    /// 파생 클래스는 이 클래스에서 선언된 추상 메서드들을 구체적으로 구현해야 합니다.
    /// </summary>
    public abstract class MotionBase : IMotionBase
    {
        // ==================== 다축 모션 컨트롤러 기능 ====================       

        /// <summary>
        /// 모션 데이터 딕셔너리를 반환합니다.
        /// 키는 축 번호, 값은 해당 축의 모션 데이터(IMotionData)입니다.
        /// </summary>
        public abstract Dictionary<int, IAxisData> GetMotionDataDictionary();  

        /// <summary>
        /// 모션 컨트롤러와 관련된 리소스를 해제합니다.
        /// 파생 클래스에서 필요한 정리 작업을 구현할 수 있습니다.
        /// </summary>
        public virtual void MotionCtrlDispose() { }

        /// <summary>
        /// 특정 축을 지정하여 상대 좌표 기준 이동 명령을 수행합니다.
        /// 이동 시 가속도와 속도를 적용합니다.
        /// </summary>
        /// <param name="axis">이동할 축 번호</param>
        /// <param name="position">상대 이동할 거리</param>
        /// <param name="velocity">이동 속도</param>
        /// <param name="acceleration">가속도</param>
        public abstract void MoveToPosition(int axis, double position, double velocity, double acceleration);

        /// <summary>
        /// 특정 축을 지정하여 절대 좌표 기준 이동 명령을 수행합니다.
        /// 이동 시 가속도와 속도를 적용합니다.
        /// </summary>
        /// <param name="axis">이동할 축 번호</param>
        /// <param name="position">절대 위치</param>
        /// <param name="velocity">이동 속도</param>
        /// <param name="acceleration">가속도</param>
        public abstract void MoveToPoint(int axis, double position, double velocity, double acceleration);

        /// <summary>
        /// 특정 축을 지정하여 지정된 위치 배열에 따라 반복 이동 명령을 수행합니다.
        /// 이동 시 가속도와 속도를 적용하며, 지정한 횟수만큼 반복합니다.
        /// </summary>
        /// <param name="axis">이동할 축 번호</param>
        /// <param name="position">이동할 위치 배열</param>
        /// <param name="velocity">이동 속도</param>
        /// <param name="acceleration">가속도</param>
        /// <param name="repeatCount">반복 횟수</param>
        public abstract void Repeat(int axis, double[] position, double velocity, double acceleration, int repeatCount);

        /// <summary>
        /// 특정 축의 모션을 정지시킵니다.
        /// </summary>
        /// <param name="axis">정지할 축 번호</param>
        public abstract bool StopMotion(int axis);

        /// <summary>
        /// 특정 축의 현재 실제 위치를 반환합니다.
        /// </summary>
        /// <param name="axis">대상 축 번호</param>
        /// <returns>현재 위치</returns>
        public abstract double GetPosition(int axis);
        //동일 내용
        //public abstract double GetCurrentPosition(int axis);

        /// <summary>
        /// 특정 축의 현재 명령 위치(목표 위치)를 반환합니다.
        /// </summary>
        /// <param name="axis">대상 축 번호</param>
        /// <returns>명령 위치</returns>
        public abstract double GetCmdPosition(int axis);

        /// <summary>
        /// 특정 축의 현재 속도를 반환합니다.
        /// </summary>
        /// <param name="axis"></param>
        /// <returns></returns>
        public abstract double GetVelocity(int axis);

        /// <summary>
        /// 특정 축의 서보를 온/오프 합니다.
        /// </summary>
        /// <param name="axis">서보 제어할 축 번호</param>
        /// <param name="enabled">true이면 서보 On, false이면 Off</param>
        public abstract void SetServoOnOff(int axis, bool enabled);

        /// <summary>
        /// 특정 축의 파라미터(셋팅)를 반환합니다.
        /// </summary>
        /// <param name="axis">대상 축 번호</param>
        /// <returns>해당 축의 모션 데이터(IMotionData)</returns>
        public abstract bool SetParameter(IAxisData motionData);

        /// <summary>
        /// 특정 축의 파라미터(셋팅)를 업데이트합니다.
        /// </summary>
        /// <param name="axis">대상 축 번호</param>
        /// <param name="motionData">새롭게 적용할 모션 데이터</param>
        /// <returns>파라미터 업데이트 성공 여부</returns>
        public abstract bool GetParameter(IAxisData motionData);

        /// <summary>
        /// 특정 축의 서보 상태를 확인합니다.
        /// </summary>
        /// <param name="axis">대상 축 번호</param>
        /// <returns>서보가 활성화되어 있으면 true, 아니면 false</returns>
        public abstract bool IsServo(int axis);

        /// <summary>
        /// 특정 축의 홈(원점) 상태를 확인합니다.
        /// </summary>
        /// <param name="axis">대상 축 번호</param>
        /// <returns>홈 상태이면 true, 아니면 false</returns>
        public abstract bool IsHomed(int axis);

        /// <summary>
        /// 특정 축의 알람을 클리어합니다.
        /// </summary>
        /// <param name="axis">알람 클리어를 수행할 축 번호</param>
        public abstract Task ClearAlarm(int axis);

        /// <summary>
        /// 특정 축의 홈 이동(원점 검색)을 수행합니다.
        /// </summary>
        /// <param name="axis">홈 이동을 수행할 축 번호</param>
        public abstract Task HomeMove(int axis, Motion_HomeConfig initset);

        /// <summary>
        /// 특정 축의 알람 상태를 확인합니다.
        /// </summary>
        /// <param name="axis">대상 축 번호</param>
        /// <returns>알람 상태이면 true, 아니면 false</returns>
        public abstract bool IsAlarm(int axis);

        /// <summary>
        /// 특정 축이 목표 위치에 도달했는지 확인합니다.
        /// </summary>
        /// <param name="axis">대상 축 번호</param>
        /// <returns>목표 위치에 도달했으면 true, 아니면 false</returns>
        public abstract bool IsMoving(int axis);

        /// <summary>
        /// 특정 축의 양(+) 리미트 상태를 확인합니다.
        /// </summary>
        /// <param name="axis">대상 축 번호</param>
        /// <returns>양 리미트 상태이면 true, 아니면 false</returns>
        public abstract bool IsPositiveLimit(int axis);

        /// <summary>
        /// 특정 축의 음(-) 리미트 상태를 확인합니다.
        /// </summary>
        /// <param name="axis">대상 축 번호</param>
        /// <returns>음 리미트 상태이면 true, 아니면 false</returns>
        public abstract bool IsNegativeLimit(int axis);

        public abstract void UpdateAllIOStatus();

        public abstract void UpdateAllPosition();

        // ==================== 유니버셜 I/O 기능 ====================

        /// <summary>
        /// 디지털 출력 명령을 실행합니다.
        /// 이 메서드는 서브 클래스에서 구현되어야 합니다.
        /// </summary>
        /// <param name="axis">출력을 제어할 축 번호</param>
        /// <param name="port">포트 번호</param>
        /// <param name="state">설정할 상태 (true: On, false: Off)</param>
        public abstract bool SetOutput(int axis, int port, bool state);

        /// <summary>
        /// 디지털 입력 조회 명령을 실행합니다.
        /// 이 메서드는 서브 클래스에서 구현되어야 합니다.
        /// </summary>
        /// <param name="axis">입력을 조회할 축 번호</param>
        /// <param name="port">포트 번호</param>
        /// <returns>입력 상태 (true: On, false: Off)</returns>
        public abstract bool GetInput(int axis, int port);

        /// <summary>
        /// 디지털 출력 조회 명령을 실행합니다.
        /// 이 메서드는 서브 클래스에서 구현되어야 합니다.
        /// </summary>
        /// <param name="axis">출력을 조회할 축 번호</param>
        /// <param name="port">포트 번호</param>
        /// <returns>출력 상태 (true: On, false: Off)</returns>
        public abstract bool GetOutput(int axis, int port);
    }

    public abstract class AxisDataBase : ViewModelBase, IAxisData
    {
        // ───────────────────────────────────────────────
        // 기본 정보
        // ───────────────────────────────────────────────
        public abstract IMotionBase Controller { get; set; }

        //기본모션상태
        public abstract bool ServoEnabled { get; set; } //서보상태
        public abstract bool HomeState { get; set; } //홈상태
        public abstract bool Alarm { get; set; } //알람
        public abstract bool PositiveLimit { get; set; } //+리미트
        public abstract bool NegativeLimit { get; set; } //-리미트
        public abstract bool InPosition { get; set; } //인포지션

        // ───────────────────────────────────────────────
        // 명령 위치 및 속도, 가속도  현재 위치 및 속도
        // ───────────────────────────────────────────────
        
        //명령 위치,속도,가속도
        public abstract double CurrentPosition { get; set; }
        public abstract double CurrentVelocity { get; set; }
        public abstract double CurrentAcceleration { get; set; }

        //현재 위치,속도
        public abstract double Position { get; set; }
        public abstract double Velocity { get; set; }

        // ───────────────────────────────────────────────
        // 셋팅 파라미터
        // ───────────────────────────────────────────────

        //기본파라미터
        public abstract ControllerType ControllerType { get; set; }
        public abstract short AxisNo { get; set; }
        public abstract string AxisName { get; set; }
        public abstract string StrAxisData { get; set; }

        //이동거리 계산에 필요한 변수
        public abstract double LeadPitch { get; set; } // 가속도 볼스크류 피치 (mm/회전)
        public abstract double PulsesPerRev { get; set; } // 모터 1회전당 펄스 수 (pulse/rev)
        public abstract double GearRatio { get; set; } // 기어비 (입력 회전수 대비 출력 회전수)

        public abstract byte PulseOutputMode { get; set; } // 펄스 출력 방식*
        public abstract byte EncInputMode { get; set; } // 엔코더 입력 방식*

        //속도 제한
        public abstract double MinSpeed { get; set; }
        public abstract double MaxSpeed { get; set; }

        // 서보 모터 활성화 반전 여부
        public abstract bool ServoEnabledReversal { get; set; }

        //레벨 설정 셋팅
        public abstract bool LvSet_EndLimitP { get; set; } // 양(+) 방향 엔드 리미트
        public abstract bool LvSet_EndLimitN { get; set; } // 음(-) 방향 엔드 리미트
        public abstract bool LvSet_SlowLimitP { get; set; } // 양(+) 방향 슬로우 리미트
        public abstract bool LvSet_SlowLimitN { get; set; } // 음(-) 방향 슬로우 리미트
        public abstract bool LvSet_InPosition { get; set; } // 위치결정 완료 신호
        public abstract bool LvSet_Alarm { get; set; } // 축의 알람 상태

        // ───────────────────────────────────────────────
        // 제어 함수
        // ───────────────────────────────────────────────
        public virtual void MoveToPosition(double position, double velocity, double acceleration)
            => Controller?.MoveToPosition(AxisNo, position, velocity, acceleration);

        public virtual void MoveToPoint(double position, double velocity, double acceleration)
            => Controller?.MoveToPoint(AxisNo, position, velocity, acceleration);

        public virtual void Repeat(double[] positions, double velocity, double acceleration, int repeatCount)
            => Controller?.Repeat(AxisNo, positions, velocity, acceleration, repeatCount);

        public virtual bool StopMotion()
            => Controller?.StopMotion(AxisNo) ?? false;
        public virtual bool SetServoOnOff(bool enabled)
        {
            Controller?.SetServoOnOff(AxisNo, enabled);
            return enabled;
        }
        public virtual Task HomeMove(Motion_HomeConfig homeConfig)
            => Controller?.HomeMove(AxisNo, homeConfig) ?? Task.CompletedTask;

        // ───────────────────────────────────────────────
        // 상태 확인 및 IO
        // 드라이버단에서 직접 데이터를 가져오는 함수        
        // ───────────────────────────────────────────────   
        public virtual double GetPosition() => Controller?.GetPosition(AxisNo) ?? 0;
        public virtual double GetCmdPosition() => Controller?.GetCmdPosition(AxisNo) ?? 0;
        public virtual double GetVelocity() => Controller?.GetVelocity(AxisNo) ?? 0;

        public virtual bool IsServo() => Controller?.IsServo(AxisNo) ?? false;
        public virtual bool IsHomed() => Controller?.IsHomed(AxisNo) ?? false;      
        public virtual bool IsAlarm() => Controller?.IsAlarm(AxisNo) ?? false;
        public virtual bool IsMoving() => Controller?.IsMoving(AxisNo) ?? false;
        public virtual bool IsPositiveLimit() => Controller?.IsPositiveLimit(AxisNo) ?? false;
        public virtual bool IsNegativeLimit() => Controller?.IsNegativeLimit(AxisNo) ?? false;
        
        public virtual bool ClearAlarm()
        {
            Controller?.ClearAlarm(AxisNo);
            return true;
        }

        // ───────────────────────────────────────────────
        // 파라미터 저장/복원
        // ───────────────────────────────────────────────
        public virtual bool GetParameter() => Controller?.GetParameter(this) ?? false;
        public virtual bool SetParameter(IAxisData motionData)
            => Controller?.SetParameter(motionData) ?? false;
    }
}
