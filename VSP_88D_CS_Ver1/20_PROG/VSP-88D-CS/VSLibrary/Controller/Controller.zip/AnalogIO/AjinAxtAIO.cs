using System.Collections.ObjectModel;
using System.Runtime.InteropServices;
using System.Threading.Channels;

namespace VSLibrary.Controller.AnlogIO
{
    /// <summary>
    /// Ajin 아날로그 I/O 보드의 데이터 관리 및 읽기/쓰기 제어를 위한 기본 클래스입니다.
    /// 이 클래스는 외부 라이브러리(CAxtLib, CAxtAIO 등)를 이용하여 보드 초기화, 채널 구성, 범위 설정 및 데이터 입출력을 수행합니다.
    /// </summary>
    public class AjinAxtAIO : AIOBase
    {
        /// <summary>
        /// 아날로그 I/O 데이터들을 와이어 이름을 키로 하여 저장하는 딕셔너리입니다.
        /// </summary>
        private Dictionary<string, IAnalogIOData> _analogIOData = new Dictionary<string, IAnalogIOData>();

        private bool _isInitialized = false;

        /// <summary>
        /// (선택적으로 사용될) DB나 다른 데이터 소스에서 읽어온 아날로그 I/O 데이터 리스트입니다.
        /// </summary>
        private readonly List<IAnalogIOData> _dBdata;

        private Dictionary<string, int> _iocount;

        /// <summary>
        /// AXTAIOCtrlBase 생성자.
        /// - 제조사가 Ajin으로 설정된 상태에서 초기화를 수행하며, 외부에서 전달받은 채널 개수를 _aiocount에 저장합니다.
        /// - 초기화 과정 중 DLL 경로 등록, 라이브러리 초기화 및 보드 채널 구성을 수행합니다.
        /// </summary>
        /// <param name="count">채널 개수를 저장한 딕셔너리 (예: "input", "output" 키 포함)</param>
        public AjinAxtAIO(Dictionary<string, int> count)
        {
            _iocount = count;
            // _dBdata에 데이터가 필요하면 초기화 가능 (현재는 사용하지 않음)
            if (IsInitialized())
            {
                OpenDevice();
                _isInitialized = true;
            }
            // 테스트용 데이터 생성 메서드 (디버깅 목적, 실제 사용 시 주석 처리 권장)
            test();            
        }

        /// <summary>
        /// 지정한 와이어 이름이 딕셔너리에 존재하는지와 초기화 상태를 확인합니다.
        /// 존재하지 않으면 오류 메시지를 출력합니다.
        /// </summary>
        /// <param name="IONo">확인할 와이어 이름</param>
        /// <returns>존재하고 초기화 상태이면 true, 그렇지 않으면 false</returns>
        private bool CheckDic(string IONo)
        {
            if (!_analogIOData.ContainsKey(IONo))
            {
                Console.WriteLine($"[오류] 디지털 IO {IONo}의 데이터가 존재하지 않습니다.");
                return false;
            }
            return true;
        }

        /// <summary>
        /// 테스트용 데이터를 생성하여 _analogIODataDictionary에 8개의 더미 데이터를 추가합니다.
        /// 주로 디버깅 목적이나 초기 동작 확인 시 사용됩니다.
        /// </summary>
        private void test()
        {
            for (int i = 0; i < 2; i++)
            {
                AIOData strdata = new AIOData
                {
                    Controller = this,
                    ControllerType = ControllerType.AIO_AjinAXT,
                    IOType = IOType.OUTPut,
                    WireName = $"AO{i + _iocount["AOutput"]:X3}",           // 예: AI000, AI001, ...
                    StrdataName = "아날로그 테스트",  // IO 이름
                    ModuleName = "",                // 모듈 이름 (필요 시 설정)
                    ModuleNumber = (short)i,
                    Channel = i,                    // 채널 번호
                    Range = i,                      // 범위 값 (테스트용)
                };

                _analogIOData.Add(strdata.WireName, strdata);
            }

            _iocount["AOutput"] = _iocount["AOutput"] + 8;
        }

        /// <summary>
        /// 제조사별 라이브러리와 보드의 아날로그 I/O 초기화를 수행합니다.
        /// 초기화에 성공하면 보드 채널 구성을 위해 OpenDevice를 호출합니다.
        /// </summary>
        /// <returns>초기화 성공 시 true, 실패 시 false</returns>
        private bool IsInitialized()
        {
            if (CAxtAIO.InitializeAIO() == 0)
            {
                return false;
            }

            OpenDevice();

            return true;
        }

        /// <summary>
        /// 보드의 아날로그 출력 및 입력 채널을 구성하고, 각 채널의 데이터를 _analogIODataDictionary에 추가합니다.
        /// 또한, 입력 및 출력 채널 개수를 _aiocount 딕셔너리에 저장합니다.
        /// </summary>
        public void OpenDevice()
        {
            // 아날로그 출력 채널 구성
            short outputChannelCount = CAxtAIO.AIOget_channel_number_dac();
            for (short i = 0; i < outputChannelCount; ++i)
            {
                short ModuleNo = CAxtAIO.AIOchannelno_2_moduleno_dac(i);
                ushort ModuleID = CAxtAIO.AIOget_moduleid(ModuleNo);

                AIOData outputData = new AIOData
                {
                    Controller = this,
                    ControllerType = ControllerType.AIO_AjinAXT,
                    IOType = IOType.OUTPut,
                    WireName = $"AO{i + _iocount["AOnput"]:X3}",  // 예: AO000, AO001, ...
                    StrdataName = "아날로그 아웃풋 테스트",
                    ModuleName = (AXT_FUNC_MODULE)ModuleID == AXT_FUNC_MODULE.AXT_SIO_AO4RB ? "SIO_AO4RB" : "SIO_AO8H",
                    ModuleNumber = ModuleNo,
                    Channel = i,
                    Range = 0,
                };
                _analogIOData.Add(outputData.WireName, outputData);
            }

            // 아날로그 입력 채널 구성
            short inputChannelCount = CAxtAIO.AIOget_channel_number_adc();
            for (short i = 0; i < inputChannelCount; ++i)
            {
                short ModuleNo = CAxtAIO.AIOchannelno_2_moduleno_adc(i);
                ushort ModuleID = CAxtAIO.AIOget_moduleid(ModuleNo);

                AIOData inputData = new AIOData
                {
                    Controller = this,
                    ControllerType = ControllerType.AIO_AjinAXT,
                    IOType = IOType.InPut,
                    WireName = $"AI{i + _iocount["AInput"]:X3}",  // 예: AI000, AI001, ...
                    StrdataName = "아날로그 인풋풋 테스트",
                    ModuleName = (AXT_FUNC_MODULE)ModuleID == AXT_FUNC_MODULE.AXT_SIO_AI4RB ? "SIO_AI4RB" : "SIO_AI16H",
                    ModuleNumber = ModuleNo,
                    Channel = i,
                    Range = 0,
                };
                _analogIOData.Add(inputData.WireName, inputData);
            }

            _iocount["AInput"] = _iocount["AInput"] + inputChannelCount;
            _iocount["AOutput"] = _iocount["AOutput"] + outputChannelCount;
        }

        /// <summary>
        /// 지정한 채널에 대해 아날로그 입력 또는 출력 범위를 설정합니다.
        /// 내부적으로 CAxtAIO 라이브러리의 AIOset_range 메서드를 호출합니다.
        /// </summary>
        /// <param name="channel">설정할 채널 번호</param>
        /// <param name="min">최소 전압 값</param>
        /// <param name="max">최대 전압 값</param>
        /// <param name="isOutput">출력 채널이면 true, 입력 채널이면 false</param>
        private void SetRange(short channel, int min, int max, bool isOutput)
        {
            try
            {
                if (isOutput)
                {
                    CAxtAIO.AIOset_range_dac(channel, min, max); // 출력 범위 설정
                }
                else
                {
                    CAxtAIO.AIOset_range_adc(channel, min, max); // 입력 범위 설정
                }
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"채널 {channel}의 범위 설정에 실패했습니다.", ex);
            }
        }

        /// <summary>
        /// AioRange 값을 기반으로 아날로그 입력 또는 출력의 범위를 설정합니다.
        /// aioRange 값은 0부터 3 사이여야 하며, 각 값에 따라 전압 범위가 다르게 설정됩니다.
        /// </summary>
        /// <param name="channel">설정할 채널 번호</param>
        /// <param name="aioRange">AioRange 값 (0: 0~10V, 1: 0~5V, 2: -10~10V, 3: -5~5V)</param>
        /// <param name="isOutput">출력 채널이면 true, 입력 채널이면 false</param>
        private void SetRangeByAioRange(short channel, int aioRange, bool isOutput)
        {
            if (aioRange < 0 || aioRange > 3)
            {
                throw new ArgumentOutOfRangeException(nameof(aioRange), "AioRange는 0에서 3 사이여야 합니다.");
            }

            switch (aioRange)
            {
                case 0:
                    SetRange(channel, 0, 10, isOutput); // 0~10V
                    break;
                case 1:
                    SetRange(channel, 0, 5, isOutput);  // 0~5V
                    break;
                case 2:
                    SetRange(channel, -10, 10, isOutput); // -10~10V
                    break;
                case 3:
                    SetRange(channel, -5, 5, isOutput);  // -5~5V
                    break;
            }
        }

        /// <summary>
        /// 특정 아날로그 입력 또는 출력의 범위를 설정합니다.
        /// 지정한 키에 해당하는 채널에 대해 Range 설정을 수행합니다.
        /// </summary>
        /// <param name="IONo">대상 와이어 이름 (현재 사용되지 않음)</param>
        /// <param name="key">설정할 AIO 데이터의 키</param>
        /// <param name="isOutput">출력 채널이면 true, 입력 채널이면 false</param>
        public void SetAioConfig(string IONo, string key, bool isOutput)
        {
            if (_analogIOData.ContainsKey(key))
            {
                int channel = _analogIOData[key].Channel;
                SetRangeByAioRange((short)channel, _analogIOData[key].Range, isOutput);
            }
            else
            {
                throw new ArgumentException("지정된 키가 AIO 데이터에 존재하지 않습니다.");
            }
        }

        /// <summary>
        /// 모든 아날로그 입력 또는 출력 채널에 대해 범위를 설정합니다.
        /// </summary>
        /// <param name="IONo">대상 와이어 이름 (현재 사용되지 않음)</param>
        /// <param name="isOutput">출력 채널이면 true, 입력 채널이면 false</param>
        public void SetAllAioConfig(int IONo, bool isOutput)
        {
            foreach (var aioData in _analogIOData.Values)
            {
                int channel = aioData.Channel;
                SetRangeByAioRange((short)channel, aioData.Range, isOutput);
            }
        }

        /// <summary>
        /// 특정 아날로그 채널의 입력 값을 읽어 반환합니다.
        /// 입력 채널의 경우 CAxtAIO.AIOread_one_volt_adc, 출력 채널의 경우 CAxtAIO.AIOread_dac를 호출합니다.
        /// </summary>
        /// <param name="AioData">읽어올 아날로그 I/O 데이터 객체</param>
        /// <returns>읽어온 아날로그 값</returns>
        /// <exception cref="ArgumentException">지정된 키가 존재하지 않을 경우</exception>
        public override double ReadChannelValue(IAnalogIOData AioData)
        {
            if (_analogIOData.ContainsKey(AioData.WireName))
            {
                int channel = _analogIOData[AioData.WireName].Channel;
                if (_analogIOData[AioData.WireName].IOType == IOType.OUTPut)
                    return CAxtAIO.AIOread_dac((short)channel);
                else
                    return CAxtAIO.AIOread_one_volt_adc((short)channel);
            }
            else
            {
                throw new ArgumentException("지정된 키가 아날로그 입력 데이터에 존재하지 않습니다.");
            }
        }

        /// <summary>
        /// 모든 아날로그 입력 채널을 일괄 읽고 내부 데이터 딕셔너리에 값을 갱신합니다.
        /// </summary>
        public override void UpdateAllChannelValues()
        {
            if (!_isInitialized) return;

            foreach (var pair in _analogIOData)
            {
                var data = pair.Value;
                short channel = (short)data.Channel;

                if (data.IOType == IOType.InPut)
                {
                    double value = CAxtAIO.AIOread_one_volt_adc(channel);
                    data.AValue = value;
                }
                else if (data.IOType == IOType.OUTPut)
                {
                    double value = CAxtAIO.AIOread_dac(channel); // 현재 출력 상태 읽기
                    data.AValue = value;
                }
            }
        }

        /// <summary>
        /// 특정 아날로그 채널에 대해 출력 값을 기록합니다.
        /// 지정한 채널의 Range에 따라 최소/최대 값을 확인한 후, 값이 범위를 벗어나면 예외를 발생시킵니다.
        /// </summary>
        /// <param name="AioData">쓰기할 아날로그 I/O 데이터 객체</param>
        /// <param name="value">설정할 아날로그 값</param>
        /// <returns>쓰기 작업 성공 여부 (성공 시 true, 실패 시 false)</returns>
        /// <exception cref="ArgumentException">지정된 키가 존재하지 않을 경우</exception>
        /// <exception cref="ArgumentOutOfRangeException">설정 값이 채널 범위를 벗어난 경우</exception>
        public override bool WriteChannelValue(IAnalogIOData AioData, double value)
        {
            if (_analogIOData.ContainsKey(AioData.WireName))
            {
                int channel = _analogIOData[AioData.WireName].Channel;
                int aioRange = _analogIOData[AioData.WireName].Range;

                // aioRange에 따른 최소값 및 최대값 설정
                int min = 0, max = 10;
                switch (aioRange)
                {
                    case 0:
                        min = 0;
                        max = 10;
                        break;
                    case 1:
                        min = 0;
                        max = 5;
                        break;
                    case 2:
                        min = -10;
                        max = 10;
                        break;
                    case 3:
                        min = -5;
                        max = 5;
                        break;
                }

                // 값이 범위를 벗어나면 예외 발생
                if (value < min || value > max)
                {
                    throw new ArgumentOutOfRangeException(nameof(value), $"값은 {min}와 {max} 사이여야 합니다.");
                }

                return CAxtAIO.AIOwrite_dac((short)channel, value) == 1 ? true : false;
            }
            else
            {
                throw new ArgumentException("지정된 키가 아날로그 출력 데이터에 존재하지 않습니다.");
            }
        }

        /// <summary>
        /// 현재 저장된 아날로그 I/O 데이터 딕셔너리를 반환합니다.
        /// </summary>
        /// <returns>와이어 이름을 키로 하고 해당 IAnalogIOData 객체를 값으로 갖는 딕셔너리</returns>
        public override Dictionary<string, IAnalogIOData> GetAnalogIODataDictionary()
        {
            return _analogIOData.ToDictionary(
                kvp => kvp.Key, kvp => kvp.Value
            );
        }

        /// <summary>
        /// 프로그램 종료 시 호출되어 보드와 관련된 리소스를 해제하는 메서드입니다.
        /// 현재 구현은 비어 있으나, 필요한 경우 리소스 해제 로직을 추가할 수 있습니다.
        /// </summary>
        public override void AnalogIOCtrlDispose()
        {
            // 보드 연결 해제 및 리소스 정리 작업을 수행
        }
    }
}
