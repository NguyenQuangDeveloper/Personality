using System.Collections.ObjectModel;
using System.Runtime.InteropServices;

namespace VSLibrary.Controller.AnlogIO
{
    /// <summary>
    /// ADLink PCI-9112 보드용 아날로그 I/O 제어 클래스
    /// (ADLink PCI-9112는 일반적으로 8채널 AI와 2채널 AO를 제공합니다.)
    /// </summary>
    public class ADLinkAIO : AIOBase
    {
		private ushort _cardNumber;
        private Dictionary<string, IAnalogIOData> _analogIOData = new Dictionary<string, IAnalogIOData>();

        private Dictionary<string, int> _iocount;

        private bool _isInitialized = false;  // 카드 초기화 여부

        /// <summary>
        /// 생성자 - 카드 초기화 및 채널 구성 수행
        /// </summary>
        public ADLinkAIO(Dictionary<string, int> count)
        {
            _iocount = count;

            if (IsInitialized())
            {
                OpenDevice();
                _isInitialized = true;
            }

            //test();
        }

        /// <summary>
        /// 테스트용 데이터를 생성하여 _analogIODataDictionary에 8개의 더미 데이터를 추가합니다.
        /// 주로 디버깅 목적이나 초기 동작 확인 시 사용됩니다.
        /// </summary>
        private void test()
        {
            for (int i = 0; i < 2; i++)
            {
                AIOData strdata = new AIOData
                {
                    Controller = this,
                    ControllerType = ControllerType.AIO_Adlink,
                    IOType = IOType.OUTPut,
                    WireName = $"AO{i + _iocount["AOutput"]:X3}",           // 예: AI000, AI001, ...
                    StrdataName = "아날로그 테스트",  // IO 이름
                    ModuleName = "",                // 모듈 이름 (필요 시 설정)
                    ModuleNumber = (short)i,
                    Channel = i,                    // 채널 번호
                    Range = i,                      // 범위 값 (테스트용)
                };

                _analogIOData.Add(strdata.WireName, strdata);
            }

            _iocount["AOutput"] = _iocount["AOutput"] + 8;
        }        

		private bool IsInitialized()
		{
			short ret = DASK.Register_Card(DASK.PCI_9112, 0);
			if (ret < 0)
			{
				Console.WriteLine($"ADLink PCI-9112 카드 등록 실패, 오류 코드: {ret}");
				return false;
				//throw new Exception($"ADLink PCI-9112 카드 등록 실패, 오류 코드: {ret}");
			}
			_cardNumber = (ushort)ret;

			return true;
		}


		/// <summary>
		/// 카드의 채널 구성
		/// AI: 8채널, AO: 2채널을 생성 및 등록합니다.
		/// </summary>
		public void OpenDevice()
        {
            // 아날로그 입력 채널 구성 (예: 8채널)
            for (int i = 0; i < 8; i++)
            {
                AIOData inputData = new AIOData
                {
                    Controller = this,
                    ControllerType = ControllerType.AIO_Adlink,
                    IOType = IOType.InPut,
                    WireName = $"AI{i + _iocount["input"]:X3}",
                    StrdataName = "아날로그 입력",
                    ModuleNumber = 0,   // 별도 모듈 번호가 필요없다면 0
                    Channel = i,
                    Range = i == 2 ? DASK.AD_U_10_V : DASK.AD_U_5_V           //// 채널별로 설정값이 다르므로 adRange 및 변환값 설정
                };

                // 필요한 경우, AI_9112_Config를 호출하여 채널 구성 (트리거 소스 등)
                // 예시: ret = DASK.AI_9112_Config(_cardNumber, 0); // 트리거 소스 0 사용
                int configRet = DASK.AI_9112_Config(_cardNumber, 0);
                if (configRet != DASK.NoError)
                {
                    throw new Exception($"AI 채널 구성 실패, 오류 코드: {configRet}");
                }

                _analogIOData.Add(inputData.WireName, inputData);                
            }
            _iocount["AInput"] = _iocount["AInput"] + 8;

            // 아날로그 출력 채널 구성 (예: 2채널)
            // AO 채널 구성 시 AO_9112_Config 함수를 사용 (참고: refVoltage 설정)
            for (int i = 0; i < 2; i++)
            {
                AIOData outputData = new AIOData
                {
                    Controller = this,
                    ControllerType = ControllerType.AIO_Adlink,
                    IOType = IOType.OUTPut,
                    WireName = $"AO{i + _iocount["output"]:X3}",
                    StrdataName = "아날로그 출력",
                    ModuleNumber = 0,
                    Channel = i,
                    Range = 0           // 예: 0은 0~10V 범위를 의미 (상황에 맞게 수정)
                };

                // 예시로 기준 전압 10.0V로 채널 구성
                double refVoltage = 10.0;
                int ret = DASK.AO_9112_Config(_cardNumber, (ushort)i, refVoltage);
                if (ret != DASK.NoError)
                {
                    throw new Exception($"AO 채널 {i} 구성 실패, 오류 코드: {ret}");
                }

                _analogIOData.Add(outputData.WireName, outputData);
            }
            _iocount["AOutput"] = _iocount["AOutput"] + 2;

            Console.WriteLine($"ADLink PCI-9112 카드 구성 완료");
        }        

        /// <summary>
        /// 특정 아날로그 채널의 입력 전압을 읽어 반환합니다.
        /// </summary>
        /// <param name="aioData">채널 데이터 정보</param>
        /// <returns>전압값 (예: 단위는 V)</returns>
        public override double ReadChannelValue(IAnalogIOData aioData)
        {
            if (!_analogIOData.ContainsKey(aioData.WireName))
            {
                throw new ArgumentException("해당 채널 데이터가 존재하지 않습니다.");
            }

            int channel = _analogIOData[aioData.WireName].Channel;
            // 예시로, Range 값에 따라 AD_B_10_V (1) 범위를 사용한다고 가정
            //ushort adRange = 1;
            ushort adRange = (ushort)_analogIOData[aioData.WireName].Range;
            ushort rawValue;
            int ret = DASK.AI_ReadChannel(_cardNumber, (ushort)channel, adRange, out rawValue);
            if (ret != DASK.NoError)
            {
                throw new Exception($"AI 채널 {channel} 읽기 실패, 오류 코드: {ret}");
            }

            // rawValue를 전압으로 변환 (AI_VoltScale 함수 사용)
            double voltage;
            ret = DASK.AI_VoltScale(_cardNumber, adRange, rawValue, out voltage);
            if (ret != DASK.NoError)
            {
                throw new Exception($"AI 채널 {channel} 전압 변환 실패, 오류 코드: {ret}");
            }

            return voltage;
        }

        /// <summary>
        /// 특정 아날로그 출력 채널에 전압 값을 출력합니다.
        /// </summary>
        /// <param name="aioData">채널 데이터 정보</param>
        /// <param name="value">출력할 전압 값 (V)</param>
        /// <returns>성공 여부</returns>
        public override bool WriteChannelValue(IAnalogIOData aioData, double value)
        {
            if (!_analogIOData.ContainsKey(aioData.WireName))
            {
                throw new ArgumentException("해당 채널 데이터가 존재하지 않습니다.");
            }

            int channel = _analogIOData[aioData.WireName].Channel;

            // AO_WriteChannel은 short 타입의 값을 받으므로,
            // 전압 값을 적절히 변환(스케일링)하여 short 값으로 변환해야 합니다.
            // 여기서는 단순 예제로, value를 정수형으로 변환합니다.
            short outValue = (short)value;

            int ret = DASK.AO_WriteChannel(_cardNumber, (ushort)channel, outValue);
            if (ret == 1)
            {
                aioData.AValue = value;  // 마지막 출력값 저장
                return true;
            }

            return false;
        }

        /// <summary>
        /// ADLink PCI-9112 보드의 모든 아날로그 입력 채널을 한 번에 읽고 내부 딕셔너리에 값을 반영합니다.
        /// 출력값은 알수 없음. 출력채널을 읽는 함수가 없음
        /// </summary>
        public override void UpdateAllChannelValues()
        {
            if (!_isInitialized) return;

            foreach (var pair in _analogIOData)
            {
                var data = pair.Value;
                if (data.IOType != IOType.InPut) continue;

                ushort rawValue;
                ushort adRange = (ushort)data.Range;
                int ret = DASK.AI_ReadChannel(_cardNumber, (ushort)data.Channel, adRange, out rawValue);
                if (ret != DASK.NoError)
                {
                    Console.WriteLine($"[ADLinkAIO] 채널 {data.Channel} 읽기 실패 (코드: {ret})");
                    continue;
                }

                double voltage;
                ret = DASK.AI_VoltScale(_cardNumber, adRange, rawValue, out voltage);
                if (ret != DASK.NoError)
                {
                    Console.WriteLine($"[ADLinkAIO] 채널 {data.Channel} 전압 변환 실패 (코드: {ret})");
                    continue;
                }

                data.AValue = voltage;
            }
        }

        /// <summary>
        /// 아날로그 채널 데이터 딕셔너리를 반환합니다.
        /// </summary>
        public override Dictionary<string, IAnalogIOData> GetAnalogIODataDictionary()
        {
            return _analogIOData;
        }

        /// <summary>
        /// 프로그램 종료 시 카드 자원을 해제합니다.
        /// </summary>
        public override void AnalogIOCtrlDispose()
        {
            DASK.Release_Card(_cardNumber);
        }
    }
}
